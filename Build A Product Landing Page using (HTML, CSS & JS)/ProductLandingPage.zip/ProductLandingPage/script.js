function imageupdate(bhu){
    document.querySelector('.image').src = bhu;
}